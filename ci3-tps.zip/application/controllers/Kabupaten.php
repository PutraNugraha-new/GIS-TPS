<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Kabupaten extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->model("M_kab");
	}

    public function index()
    {
        $data = array(
            'title2'=>'Data Kabupaten',
            'user' => 'Putra Nugraha',
            'isi'   =>  'admin/kabupaten/v_home',
            'kab' => $this->M_kab->allData(),
        );
        // var_dump($data);
        $this->load->view('admin/layout/v_wrapper', $data, FALSE);
    }

    public function edit($id)
    {
        $data = array(
            'title2'=>'Data TPS',
            'user' => 'Putra Nugraha',
            'isi'   =>  'admin/kabupaten/v_edit',
            'kab' => $this->M_kab->allData(),
        );
        // var_dump($data);
        $this->load->view('admin/layout/v_wrapper', $data, FALSE);
    }

    public function update($id){
        $i = $this->input;
            $data = array(
                'id_tps'	=> $id,
                'nama_tps'	=> $i->post('nama_tps'),
                'kode_kab'	=> $i->post('kode_kab'),
                'kode_kec'	=> $i->post('kode_kec'),
                'kode_kel'	=> $i->post('kode_kel'),
                'alamat'			=> $i->post('alamat'),
                'latitude'			=> $i->post('latitude'),
                'longitude'			=> $i->post('longitude')
            );
            $this->M_tps->edit($data);
            $this->session->set_flashdata('sukses', ' Data TPS Berhasil DIUPDATE !');
            redirect('admin', 'refresh');

            $data = array(

                'title2'=>'Data TPS',
                'user' => 'Putra Nugraha',
                'isi'   =>  'admin/kabupaten/v_home',
            );
		$this->load->view('admin/layout/v_wrapper', $data, FALSE);
    }

    public function add()
	{
            $i = $this->input;
            $data = array(
                'kode_kab'	=> $i->post('kode_kab'),
                'nama_kab'	=> $i->post('nama_kab'),
            );
            $this->M_kab->add($data);
            $this->session->set_flashdata('sukses', ' Data Kabupaten Berhasil Ditambahkan !');
            redirect('Kabupaten', 'refresh');

            $data = array(

                'title2'=>'Data TPS',
                'user' => 'Putra Nugraha',
                'isi'   =>  'admin/kabupaten/v_home',
            );
		$this->load->view('admin/layout/v_wrapper', $data, FALSE);
	}

    //Delete one item
	public function hapus($id)
	{
		$data = array('kode_kab' => $id);
		$this->M_kab->delete($data);
		$this->session->set_flashdata('sukses', 'Data Berhasil Dihapus');
		redirect('kabupaten', 'refresh');
	}



}

/* End of file Admin.php */

